if (CQ_Analytics.CustomStoreMgr) {

    CQ_Analytics.CustomStoreMgr.template =
            "<input class='customstore-input' type='text' id='customstore-input-%key%' name='%key%' value='%value%'>" +
            "<label for='customstore-input-%key%'>%label%</label>";

    CQ_Analytics.CustomStoreMgr.templateRenderer = function (key, label, value) {
        var template = CQ_Analytics.CustomStoreMgr.template;
        return template.replace(/%label%/g, label)
                .replace(/%key%/g, key)
                .replace(/%value%/g, value);
    }


    CQ_Analytics.CustomStoreMgr.renderer = function (store, divId) {

        // first load data
        CQ_Analytics.CustomStoreMgr.loadData();

        $CQ("#" + divId).children().remove();

        var name = CQ_Analytics.ProfileDataMgr.getProperty("formattedName");
        var templateRenderer = CQ_Analytics.CustomStoreMgr.templateRenderer;

        // Set title
        $CQ("#" + divId).addClass("cq-cc-customstore");
        var div = $CQ("<div>").html(name + " profile");
        $CQ("#" + divId).append(div);


        var data = this.getJSON();

        // var data = [];      
        // data.push({'key':'NAICS', 'label':'NAICS Industry Code','value':'1904'})       
        console.log('data: ' + JSON.stringify(data));

        if (data) {
            for (var i in data) {
                if (typeof data[i] === 'object') {
                    $CQ("#" + divId).append(templateRenderer(data[i].key, data[i].label, data[i].value));
                }
            }
        }



    }
    CQ_Analytics.ClickstreamcloudMgr.register(CQ_Analytics.CustomStoreMgr);

}